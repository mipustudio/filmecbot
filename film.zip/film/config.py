

token='6197992982:AAHBik5iunihA_WPdBuwg-s3jfF4XNYmY-M' #https://t.me/BotFather
admin_id=int(671065514) #https://t.me/getidsbot

